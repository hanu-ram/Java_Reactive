package com.ford.ricoh.dmtinoutapi.batch.notification.config;

import com.ford.ricoh.dmtinoutapi.batch.notification.tasklet.*;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
public class BatchConfig {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final SsdWebExNotificationTasklet ssdWebExNotificationTasklet;
    private final VanwaganenWebExNotificationTasklet vanwaganenWebExNotificationTasklet;
    private final SsdNtWebExNotificationTasklet ssdNtWebExNotificationTasklet;
    private final PifWebExNotificationTasklet pifWebExNotificationTasklet;
    private final DmtDocsWithBarcodeNotificationTasklet dmtDocsWithBarcodeNotificationTasklet;
    private final DmtDocsWithoutBarcodeNotificationTasklet dmtDocsWithoutBarcodeNotificationTasklet;

    @Bean
    public Step ssdNotificationStep() {
        return new StepBuilder("ssdNotificationStep", jobRepository)
                .tasklet(ssdWebExNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Step vanwaganenNotificationStep() {
        return new StepBuilder("vanwaganenNotificationStep", jobRepository)
                .tasklet(vanwaganenWebExNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Step ssdNtNotificationStep() {
        return new StepBuilder("ssdNtNotificationStep", jobRepository)
                .tasklet(ssdNtWebExNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Step pifNotificationStep() {
        return new StepBuilder("pifNotificationStep", jobRepository)
                .tasklet(pifWebExNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Step dmtDocsWithBarcodeNotificationStep() {
        return new StepBuilder("dmtDocsWithBarcodeNotificationStep", jobRepository)
                .tasklet(dmtDocsWithBarcodeNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Step dmtDocsWithoutBarcodeNotificationStep() {
        return new StepBuilder("dmtDocsWithoutBarcodeNotificationStep", jobRepository)
                .tasklet(dmtDocsWithoutBarcodeNotificationTasklet, transactionManager)
                .build();
    }

    @Bean
    public Flow inboundWebExNotificationFlow1() {
        return new FlowBuilder<Flow>("inboundWebExNotificationFlow1")
                .start(ssdNotificationStep())
                .next(ssdNtNotificationStep())
                .build();
    }

    @Bean
    public Flow inboundWebExNotificationFlow2() {
        return new FlowBuilder<Flow>("inboundWebExNotificationFlow2")
                .start(vanwaganenNotificationStep())
                .next(pifNotificationStep())
                .build();
    }
    public Flow inoundWebExNotificationFlow3() {
        return new FlowBuilder<Flow>("inboundWebExNotificationFlow3")
                .start(dmtDocsWithBarcodeNotificationStep())
                .next(dmtDocsWithoutBarcodeNotificationStep())
                .build();
    }

    @Bean
    public Flow inboundWebExNotificationFlow() {
        return new FlowBuilder<Flow>("inboundWebExNotificationFlow")
                .split(simpleTaskExecutor())
                .add(inboundWebExNotificationFlow1(), inboundWebExNotificationFlow2(), inoundWebExNotificationFlow3())
                .build();
    }

    @Bean
    public Job inboundNotificationJob() {
        return new JobBuilder("inboundNotificationJob", jobRepository)
                .start(inboundWebExNotificationFlow())
                .end()
                .build();
    }

    @Bean
    public TaskExecutor simpleTaskExecutor() {
        SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
        taskExecutor.setThreadNamePrefix("inboundNotification-");
        taskExecutor.setConcurrencyLimit(4);
        return taskExecutor;
    }
}
