package com.ford.ricoh.dmtinoutapi.batch.notification.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Setter
@Getter
@ConfigurationProperties(prefix = "inbound.batch.webhook")
public class WebhookChannelUrl {
    private String ssdChannel;
    private String pifChannel;
    private String vanwaganenChannel;
    private String dmtChannel;
}
