package com.ford.ricoh.dmtinoutapi.batch.notification.constants;

import lombok.Getter;

@Getter
public enum BatchStatusMetaConstants {

    BATCH_STATUS_META_ID("id"),
    BATCH_STATUS_META_FILE_NAME("fileName"),
    BATCH_STATUS_META_ORIGINAL_FILE_NAME("originalFileName"),
    BATCH_STATUS_META_PROCESS_RUN_NUMBER("processRunNumber"),
    BATCH_STATUS_META_TIMESTAMP("timestamp"),
    BATCH_STATUS_META_PROCESS_ID("processId"),
    BATCH_STATUS_META_BATCH_TYPE("batchType"),
    BATCH_STATUS_META_PROCESS_STAGE_ID("processStageId"),
    BATCH_STATUS_META_BATCH_NUMBER("batchNumber"),
    BATCH_STATUS_META_CLOUD_STORAGE_PATH("cloudstoragePath"),
    BATCH_STATUS_META_PROCESSED_OK("processedOk"),
    BATCH_STATUS_META_IS_ALREADY_RUN("isAlreadyRun"),
    BATCH_STATUS_META_IGNORE_BATCH_STATUS_METADATA_PERSISTENCE("ignoreBatchStatusMetadataPersistence"),
    BATCH_STATUS_META_BATCH_ERROR_DETAILS("batchErrorDetails"),
    BATCH_STATUS_META_LAST_UPDATE_USERID("lastUpdateUserid"),
    BATCH_STATUS_META_LAST_UPDATE_TIMESTAMP("lastUpdateTimestamp"),
    BATCH_STATUS_META_TOTAL_NUMBER_OF_FILES("totalNumberOfFiles");
    private final String value;
    BatchStatusMetaConstants(String value) {
        this.value = value;
    }
}
