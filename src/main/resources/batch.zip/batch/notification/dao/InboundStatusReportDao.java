package com.ford.ricoh.dmtinoutapi.batch.notification.dao;

import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;

import java.sql.Timestamp;
import java.util.List;

public interface InboundStatusReportDao {
    Long getAllSuccessfulFilesCountByProcessIdAndTimeStamp(String processId, Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getSsdFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getSsdFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getSsdNtFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getSsdNtFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getPifFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getPifFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getTotalNumberOfVanwagenenFilesByTimestamp(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getTotalNumberOfDmtDocsWithBarcodeFiles(Timestamp timeStampAfter, Timestamp timeStampBefore);
    List<BatchStatusMetaEntity> getTotalNumberOfDmtDocsWithoutBarcodeFiles(Timestamp timeStampAfter, Timestamp timeStampBefore);
}
