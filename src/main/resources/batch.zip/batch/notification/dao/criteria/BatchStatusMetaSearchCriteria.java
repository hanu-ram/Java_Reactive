package com.ford.ricoh.dmtinoutapi.batch.notification.dao.criteria;

import com.ford.ricoh.dmtinoutapi.batch.notification.dao.operation.BatchStatusMetaOperation;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class BatchStatusMetaSearchCriteria {
    private String key;
    private Object value;
    private List<Object> values;
    private BatchStatusMetaOperation operation;

    public BatchStatusMetaSearchCriteria(String key, Object value, BatchStatusMetaOperation operation) {
        this.key = key;
        this.value = value;
        this.operation = operation;
    }

    public BatchStatusMetaSearchCriteria(String key, List<Object> values, BatchStatusMetaOperation operation) {
        this.key = key;
        this.values = values;
        this.operation = operation;
    }
}
