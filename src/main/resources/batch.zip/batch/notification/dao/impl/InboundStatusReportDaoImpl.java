package com.ford.ricoh.dmtinoutapi.batch.notification.dao.impl;

import com.ford.ricoh.dmtinoutapi.batch.notification.constants.BatchStatusMetaConstants;
import com.ford.ricoh.dmtinoutapi.batch.notification.dao.InboundStatusReportDao;
import com.ford.ricoh.dmtinoutapi.batch.notification.dao.criteria.BatchStatusMetaSearchCriteria;
import com.ford.ricoh.dmtinoutapi.batch.notification.dao.operation.BatchStatusMetaOperation;
import com.ford.ricoh.dmtinoutapi.batch.notification.dao.specs.BatchStatusMetaSpecification;
import com.ford.ricoh.dmtinoutapi.constants.InboundProcessStageIdEnum;
import com.ford.ricoh.dmtinoutapi.constants.InboundProcessTypeEnum;
import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;
import com.ford.ricoh.dmtinoutapi.repository.RicohDocMetaRepository;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class InboundStatusReportDaoImpl implements InboundStatusReportDao {
    private final RicohDocMetaRepository ricohDocMetaRepository;
    private final EntityManager entityManager;

    @Override
    public Long getAllSuccessfulFilesCountByProcessIdAndTimeStamp(String processId, Timestamp timeStampAfter, Timestamp timeStampBefore) {
        return ricohDocMetaRepository.countByProcessIdAndCreatedTimestampAfterAndCreatedTimestampBefore(processId, timeStampAfter, timeStampBefore);
    }

    @Override
    public List<BatchStatusMetaEntity> getSsdFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForCscmFailed(
                specification,
                InboundProcessTypeEnum.SSD,
                timeStampAfter,
                timeStampBefore,
                false
        );
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getSsdFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForInvalidData(
                specification,
                InboundProcessTypeEnum.SSD,
                timeStampAfter,
                timeStampBefore,
                false);
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getSsdNtFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForCscmFailed(
                specification,
                InboundProcessTypeEnum.SSD,
                timeStampAfter,
                timeStampBefore,
                true
        );
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getSsdNtFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForInvalidData(
                specification,
                InboundProcessTypeEnum.SSD,
                timeStampAfter,
                timeStampBefore,
                true
        );
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getPifFailedFilesForCscmFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForCscmFailed(
                specification,
                InboundProcessTypeEnum.PIF,
                timeStampAfter,
                timeStampBefore,
                false
        );
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getPifFailedFilesForDataValidationFailureSpec(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        buildCriteriaForSsdAndPifBasedOnFileNameMatchForInvalidData(
                specification,
                InboundProcessTypeEnum.PIF,
                timeStampAfter,
                timeStampBefore,
                false
        );
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getTotalNumberOfVanwagenenFilesByTimestamp(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        commonCriteria(
                specification,
                InboundProcessTypeEnum.VAN_WAGENEN,
                InboundProcessStageIdEnum.UNZIP_DECRYPT_FILE,
                timeStampAfter,
                timeStampBefore
        );
        specification.setDistinct(true);
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_ORIGINAL_FILE_NAME.getValue());
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_PROCESS_STAGE_ID.getValue());
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_TOTAL_NUMBER_OF_FILES.getValue());
        return specification.findByCriteria();
    }

    @Override
    public List<BatchStatusMetaEntity> getTotalNumberOfDmtDocsWithBarcodeFiles(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        return commonCriteriaForTotalNumberOfDmtFiles(timeStampAfter, timeStampBefore, "DocsWithBarcode");
    }

    @Override
    public List<BatchStatusMetaEntity> getTotalNumberOfDmtDocsWithoutBarcodeFiles(Timestamp timeStampAfter, Timestamp timeStampBefore) {
        return commonCriteriaForTotalNumberOfDmtFiles(timeStampAfter, timeStampBefore, "DocsWithoutBarcode");
    }

    private List<BatchStatusMetaEntity> commonCriteriaForTotalNumberOfDmtFiles(
            Timestamp timeStampAfter,
            Timestamp timeStampBefore,
            String originalFileName) {
        BatchStatusMetaSpecification specification = new BatchStatusMetaSpecification(entityManager);
        commonCriteria(
                specification,
                InboundProcessTypeEnum.DMT,
                InboundProcessStageIdEnum.WRITE_FILE_TO_GCS,
                timeStampAfter,
                timeStampBefore
        );
        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(
                BatchStatusMetaConstants.BATCH_STATUS_META_ORIGINAL_FILE_NAME.getValue(),
                originalFileName, BatchStatusMetaOperation.MATCH));
        return specification.findByCriteria();
    }
    private static void buildCriteriaForSsdAndPifBasedOnFileNameMatchForCscmFailed(
            BatchStatusMetaSpecification specification,
            InboundProcessTypeEnum inboundProcessTypeEnum,
            Timestamp timeStampAfter,
            Timestamp timeStampBefore,
            boolean isNotarized
    ) {
        commonCriteria(
                specification,
                inboundProcessTypeEnum,
                InboundProcessStageIdEnum.INBOUND_BATCH_CSCM_UPLOAD_ERROR_SEND_EMAIL,
                timeStampAfter,
                timeStampBefore
        );
        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_ORIGINAL_FILE_NAME.getValue(),
                InboundProcessTypeEnum.NOTARIZED.getValue(), isNotarized ? BatchStatusMetaOperation.MATCH : BatchStatusMetaOperation.NOT_MATCH));
        specification.setDistinct(true);
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_FILE_NAME.getValue());
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_PROCESS_STAGE_ID.getValue());
    }

    private static void buildCriteriaForSsdAndPifBasedOnFileNameMatchForInvalidData(
            BatchStatusMetaSpecification specification,
            InboundProcessTypeEnum inboundProcessTypeEnum,
            Timestamp timeStampAfter,
            Timestamp timeStampBefore,
            boolean isNotarized
    ) {
        commonCriteria(
                specification,
                inboundProcessTypeEnum,
                InboundProcessStageIdEnum.SSD_PIF_DATA_VALIDATION,
                timeStampAfter,
                timeStampBefore
        );
        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_ORIGINAL_FILE_NAME.getValue(),
                InboundProcessTypeEnum.NOTARIZED.getValue(), isNotarized ? BatchStatusMetaOperation.MATCH : BatchStatusMetaOperation.NOT_MATCH));
        specification.setDistinct(true);
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_FILE_NAME.getValue());
        specification.setFieldList(BatchStatusMetaConstants.BATCH_STATUS_META_PROCESS_STAGE_ID.getValue());
    }

    private static void commonCriteria(
            BatchStatusMetaSpecification specification,
            InboundProcessTypeEnum inboundProcessTypeEnum,
            InboundProcessStageIdEnum inboundProcessStageIdEnum,
            Timestamp timeStampAfter,
            Timestamp timeStampBefore
    ) {
        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_PROCESS_ID.getValue(),
                inboundProcessTypeEnum.getValue(), BatchStatusMetaOperation.EQUAL));

        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_PROCESS_STAGE_ID.getValue(),
                inboundProcessStageIdEnum.getValue(), BatchStatusMetaOperation.EQUAL));

        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_TIMESTAMP.getValue(),
                timeStampAfter, BatchStatusMetaOperation.GREATER_THAN_EQUAL));

        specification.addSearchCriteria(new BatchStatusMetaSearchCriteria(BatchStatusMetaConstants.BATCH_STATUS_META_TIMESTAMP.getValue(),
                timeStampBefore, BatchStatusMetaOperation.LESS_THAN_EQUAL));
    }

}
