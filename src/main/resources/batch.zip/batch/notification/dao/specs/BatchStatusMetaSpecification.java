package com.ford.ricoh.dmtinoutapi.batch.notification.dao.specs;

import com.ford.ricoh.dmtinoutapi.batch.notification.dao.criteria.BatchStatusMetaSearchCriteria;
import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.*;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class BatchStatusMetaSpecification {
    private final List<BatchStatusMetaSearchCriteria> searchCriteriaList;
    private final Root<BatchStatusMetaEntity> root;
    private final CriteriaQuery<BatchStatusMetaEntity> query;
    private final CriteriaBuilder criteriaBuilder;
    private final EntityManager entityManager;
    @Setter
    private boolean distinct;
    private final List<Selection<?>> selectFieldList = new ArrayList<>();

    public BatchStatusMetaSpecification(EntityManager entityManager) {
        this.entityManager = entityManager;
        searchCriteriaList = new ArrayList<>();
        criteriaBuilder = entityManager.getCriteriaBuilder();
        query = criteriaBuilder.createQuery(BatchStatusMetaEntity.class);
        root = query.from(BatchStatusMetaEntity.class);
    }

    public void setFieldList(String field) {
        selectFieldList.add(root.get(field));
    }

    public void addSearchCriteria(BatchStatusMetaSearchCriteria searchCriteria) {
        searchCriteriaList.add(searchCriteria);
    }

    public List<BatchStatusMetaEntity> findByCriteria() {
        query.where(toPredicate());
        return entityManager.createQuery(query).getResultList();
    }

    @SuppressWarnings("unchecked")
    private Predicate toPredicate() {
        List<Predicate> predicates = new ArrayList<>();

        for (BatchStatusMetaSearchCriteria criteria : searchCriteriaList) {
            switch (criteria.getOperation()) {
                case GREATER_THAN -> predicates.add(criteriaBuilder.greaterThan(
                        root.get(criteria.getKey()),
                        getObjectByClassType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case LESS_THAN -> predicates.add(criteriaBuilder.lessThan(
                        root.get(criteria.getKey()),
                        getObjectByClassType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case GREATER_THAN_EQUAL -> predicates.add(criteriaBuilder.greaterThanOrEqualTo(
                        root.get(criteria.getKey()),
                        getObjectByClassType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case LESS_THAN_EQUAL -> predicates.add(criteriaBuilder.lessThanOrEqualTo(
                        root.get(criteria.getKey()),
                        getObjectByClassType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case EQUAL -> predicates.add(criteriaBuilder.equal(
                        root.get(criteria.getKey()),
                        castToRequiredType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case NOT_EQUAL -> predicates.add(criteriaBuilder.notEqual(
                        root.get(criteria.getKey()),
                        castToRequiredType(root.get(criteria.getKey()).getJavaType(), criteria.getValue().toString())
                ));
                case MATCH -> predicates.add(criteriaBuilder.like(
                        root.get(criteria.getKey()),
                        "%" + criteria.getValue() + "%"
                ));
                case NOT_MATCH -> predicates.add(criteriaBuilder.notLike(
                        root.get(criteria.getKey()),
                        "%" + criteria.getValue() + "%"
                ));
                case MATCH_START -> predicates.add(criteriaBuilder.like(
                        root.get(criteria.getKey()),
                        "%" + criteria.getValue()
                ));
                case MATCH_END -> predicates.add(criteriaBuilder.like(
                        root.get(criteria.getKey()),
                        criteria.getValue() + "%"
                ));
                case IN -> predicates.add(criteriaBuilder.in(
                                root.get(criteria.getKey()))
                        .value(criteria.getValues())
                );
                case NOT_IN -> predicates.add(criteriaBuilder.in(
                                root.get(criteria.getKey()))
                        .value(criteria.getValues()).not()
                );
            }
        }
        if (distinct) {
            query.distinct(true);
        }
        if (!selectFieldList.isEmpty()) {
            query.multiselect(selectFieldList);
        } else {
            query.select(root);
        }
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    private Object castToRequiredType(Class<?> fieldType, String value) {
        if (fieldType.isAssignableFrom(Long.class)) {
            return Long.valueOf(value);
        } else if (fieldType.isAssignableFrom(Integer.class)) {
            return Integer.valueOf(value);
        } else if (fieldType.isAssignableFrom(Timestamp.class)) {
            return Timestamp.valueOf(value);
        }
        return value;
    }

    @SuppressWarnings("rawtypes")
    private Expression getObjectByClassType(Class<?> fieldType, String value) {
        if (fieldType.isAssignableFrom(Double.class)) {
            return criteriaBuilder.literal(Double.valueOf(value));
        } else if (fieldType.isAssignableFrom(Integer.class)) {
            return criteriaBuilder.literal(Integer.valueOf(value));
        } else if (fieldType.isAssignableFrom(Timestamp.class)) {
            return criteriaBuilder.literal(Timestamp.valueOf(value));
        } else if (fieldType.isAssignableFrom(Long.class)) {
            return criteriaBuilder.literal(Long.valueOf(value));
        }
        return criteriaBuilder.literal(value);
    }
}
