package com.ford.ricoh.dmtinoutapi.batch.notification.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MessageRequestDto {
    private String roomId;
    private String markdown;
    private String text;
}
