package com.ford.ricoh.dmtinoutapi.batch.notification.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageResponseDto {
    private String id;
    private String roomId;
    private String roomType;
    private String text;
    private String personId;
    private String personEmail;
    private String created;
    private String html;
}
