package com.ford.ricoh.dmtinoutapi.batch.notification.service;

import org.springframework.stereotype.Service;

@Service
public sealed interface NotificationService permits SsdNotificationService, VanwaganenNotificationService, PifNotificationService, SsdNtNotificationService, DmtDocsWithBarcodeNotificationService, DmtDocsWithoutBarcodeNotificationService {

    void sendWebExNotification();

}
