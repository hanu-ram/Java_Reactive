package com.ford.ricoh.dmtinoutapi.batch.notification.service;

import com.ford.ricoh.dmtinoutapi.batch.notification.dao.InboundStatusReportDao;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageRequestDto;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageResponseDto;
import com.ford.ricoh.dmtinoutapi.batch.notification.utils.CommonBatchUtils;
import com.ford.ricoh.dmtinoutapi.constants.InboundProcessTypeEnum;
import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@PropertySource(value = "classpath:constants/inboundconstants.properties")
public final class SsdNotificationService implements NotificationService {
    private final InboundStatusReportDao inboundStatusReportDao;
    private final WebExService webExService;

    @Value("${inbound.notification.ssd.subject}")
    private String subject;

    @Value("${inbound.notification.ssd.status1}")
    private String status1;

    @Value("${inbound.notification.ssd.status2}")
    private String status2;
    @Value("${inbound.notification.ssd.status3:empty}")
    private String status3;
    @Value("${inbound.batch.notification.timestamp.from}")
    private String from;
    @Value("${inbound.batch.notification.timestamp.to}")
    private String to;


    @Override
    public void sendWebExNotification() {
        log.info("SsdWebExNotificationTasklet started");
        String utc = LocalDate.now(ZoneId.of("UTC")).toString();
        String timeStampAfter = utc + " " + from;
        String timeStampBefore = utc + " " + to;
        List<BatchStatusMetaEntity> ssdFailedFilesForCscmFailureSpec = inboundStatusReportDao.getSsdFailedFilesForCscmFailureSpec(
                Timestamp.valueOf(timeStampAfter),
                Timestamp.valueOf(timeStampBefore)
        );
        List<BatchStatusMetaEntity> ssdFailedFilesForDataValidationFailure = inboundStatusReportDao.getSsdFailedFilesForDataValidationFailureSpec(
                Timestamp.valueOf(timeStampAfter),
                Timestamp.valueOf(timeStampBefore)
        );
        int failureCount = ssdFailedFilesForDataValidationFailure.size() + ssdFailedFilesForCscmFailureSpec.size();
        Long successCount = inboundStatusReportDao.getAllSuccessfulFilesCountByProcessIdAndTimeStamp(
                InboundProcessTypeEnum.SSD.getValue(),
                Timestamp.valueOf(timeStampAfter),
                Timestamp.valueOf(timeStampBefore)
        );
        MessageRequestDto messageRequestDto = CommonBatchUtils.createMessageRequestDto(subject, status1, status2, status3, successCount, failureCount, utc);
        ResponseEntity<MessageResponseDto> response = webExService.pushMessageIntoSsdWebexChannel(messageRequestDto);
        log.info("SsdNotificationService::sendWebExNotification WebEx Notification Sent Successfully status: {}", response.getStatusCode());
    }

}
