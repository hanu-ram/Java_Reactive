package com.ford.ricoh.dmtinoutapi.batch.notification.service;

import com.ford.ricoh.dmtinoutapi.batch.notification.dao.InboundStatusReportDao;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageRequestDto;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageResponseDto;
import com.ford.ricoh.dmtinoutapi.batch.notification.utils.CommonBatchUtils;
import com.ford.ricoh.dmtinoutapi.constants.InboundProcessTypeEnum;
import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public final class VanwaganenNotificationService implements NotificationService {
    private final InboundStatusReportDao inboundStatusReportDao;
    private final WebExService webExService;

    @Value("${inbound.notification.vw.subject}")
    private String subject;

    @Value("${inbound.notification.vw.status1}")
    private String status1;

    @Value("${inbound.notification.vw.status2}")
    private String status2;
    @Value("${inbound.notification.vw.status3:empty}")
    private String status3;
    @Value("${inbound.batch.notification.timestamp.from}")
    private String from;
    @Value("${inbound.batch.notification.timestamp.to}")
    private String to;

    @Override
    public void sendWebExNotification() {
        log.info("VanwaganenNotificationService::sendWebExNotification Collecting Data & Preparing to send WebEx Notification");
        String utc = LocalDate.now(ZoneId.of("UTC")).toString();
        String timeStampAfter = utc + " " + from;
        String timeStampBefore = utc + " " + to;
        Long allSuccessfulFilesCountByProcessIdAndTimeStamp = inboundStatusReportDao.getAllSuccessfulFilesCountByProcessIdAndTimeStamp(
                InboundProcessTypeEnum.VAN_WAGENEN.getValue(),
                Timestamp.valueOf(timeStampAfter),
                Timestamp.valueOf(timeStampBefore)
        );
        List<BatchStatusMetaEntity> totalNumberOfVanwagenenFilesByTimestamp = inboundStatusReportDao.getTotalNumberOfVanwagenenFilesByTimestamp(
                Timestamp.valueOf(timeStampAfter),
                Timestamp.valueOf(timeStampBefore)
        );
        int sumOfTotalNumberOfFiles = totalNumberOfVanwagenenFilesByTimestamp.stream().mapToInt(BatchStatusMetaEntity::getTotalNumberOfFiles).sum();
        int failureCount = sumOfTotalNumberOfFiles - allSuccessfulFilesCountByProcessIdAndTimeStamp.intValue();

        MessageRequestDto messageRequestDto = CommonBatchUtils.createMessageRequestDto(
                subject,
                status1,
                status2,
                status3,
                allSuccessfulFilesCountByProcessIdAndTimeStamp,
                failureCount,
                utc
        );
        ResponseEntity<MessageResponseDto> response = webExService.pushMessageIntoVanwaganenWebexChannel(messageRequestDto);
        log.info("VanwaganenNotificationService::sendWebExNotification WebEx Notification Sent Successfully status: {}", response.getStatusCode());
    }
}
