package com.ford.ricoh.dmtinoutapi.batch.notification.service;

import com.ford.ricoh.dmtinoutapi.batch.notification.config.WebhookChannelUrl;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageRequestDto;
import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageResponseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
@Slf4j
@RequiredArgsConstructor
public class WebExService {
    private final WebhookChannelUrl webhookChannelUrl;

    public ResponseEntity<MessageResponseDto> pushMessageIntoSsdWebexChannel(MessageRequestDto message) {
        log.info("WebExService::postMessageUsingHook sending message to SSD channel");
        return this.commonRestInvocationForWebex(webhookChannelUrl.getSsdChannel(), message);
    }

    public ResponseEntity<MessageResponseDto> pushMessageIntoPifWebexChannel(MessageRequestDto message) {
        log.info("WebExService::pushMessageIntoPifWebexChannel sending message to PIF channel");
        return this.commonRestInvocationForWebex(webhookChannelUrl.getPifChannel(), message);
    }

    public ResponseEntity<MessageResponseDto> pushMessageIntoVanwaganenWebexChannel(MessageRequestDto message) {
        log.info("WebExService::pushMessageIntoVanwaganenWebexChannel sending message to Vanwaganen channel");
        return this.commonRestInvocationForWebex(webhookChannelUrl.getVanwaganenChannel(), message);
    }

    public ResponseEntity<MessageResponseDto> pushMessageIntoDmtWebexChannel(MessageRequestDto message) {
        log.info("WebExService::pushMessageIntoDmtWebexChannel sending message to DMT channel");
        return this.commonRestInvocationForWebex(webhookChannelUrl.getDmtChannel(), message);
    }

    private ResponseEntity<MessageResponseDto> commonRestInvocationForWebex(
            String webhookUrl,
            MessageRequestDto messageRequestDto
    ) {
        RestClient restClient = RestClient.builder().baseUrl(webhookUrl)
                .build();
        return restClient.post()
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(messageRequestDto)
                .retrieve()
                .toEntity(MessageResponseDto.class);
    }
}
