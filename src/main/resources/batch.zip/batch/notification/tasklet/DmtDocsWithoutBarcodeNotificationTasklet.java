package com.ford.ricoh.dmtinoutapi.batch.notification.tasklet;

import com.ford.ricoh.dmtinoutapi.batch.notification.service.DmtDocsWithoutBarcodeNotificationService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class DmtDocsWithoutBarcodeNotificationTasklet implements Tasklet {
    private final DmtDocsWithoutBarcodeNotificationService dmtDocsWithoutBarcodeNotificationService;

    @Override
    public RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) {
        log.info("DmtDocsWithoutBarcodeNotificationTasklet started");
        dmtDocsWithoutBarcodeNotificationService.sendWebExNotification();
        log.info("DmtDocsWithoutBarcodeNotificationTasklet executed");
        return RepeatStatus.FINISHED;
    }
}
