package com.ford.ricoh.dmtinoutapi.batch.notification.tasklet;

import com.ford.ricoh.dmtinoutapi.batch.notification.service.SsdNotificationService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Slf4j
@Component
public class SsdWebExNotificationTasklet implements Tasklet {

    private final SsdNotificationService ssdNotificationService;

    @Override
    public RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) {
        log.info("SsdWebExNotificationTasklet started");
        ssdNotificationService.sendWebExNotification();
        log.info("SsdWebExNotificationTasklet executed");
        return RepeatStatus.FINISHED;
    }
}
