package com.ford.ricoh.dmtinoutapi.batch.notification.tasklet;

import com.ford.ricoh.dmtinoutapi.batch.notification.service.NotificationService;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class VanwaganenWebExNotificationTasklet implements Tasklet {

    private final NotificationService vanwaganenNotificationService;

    public VanwaganenWebExNotificationTasklet(@Qualifier("vanwaganenNotificationService") NotificationService vanwaganenNotificationService) {
        this.vanwaganenNotificationService = vanwaganenNotificationService;
    }

    @Override
    public RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) {
        log.info("VanWaganenWebExNotificationTasklet started");
        vanwaganenNotificationService.sendWebExNotification();
        log.info("VanWaganenWebExNotificationTasklet executed");
        return RepeatStatus.FINISHED;
    }
}
