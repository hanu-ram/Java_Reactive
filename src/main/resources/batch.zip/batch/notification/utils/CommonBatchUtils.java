package com.ford.ricoh.dmtinoutapi.batch.notification.utils;

import com.ford.ricoh.dmtinoutapi.batch.notification.dto.MessageRequestDto;
import com.ford.ricoh.dmtinoutapi.constants.TokenConstants;
import com.ford.ricoh.dmtinoutapi.entity.BatchStatusMetaEntity;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@Slf4j
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public final class CommonBatchUtils {

    public static MessageRequestDto createMessageRequestDto(
            String subject,
            String status1,
            String status2,
            String status3,
            Long successCount,
            int failureCount,
            String utc
    ) {
        String markdown;
        int totalNumberOfFiles = successCount.intValue() + failureCount;
        MessageRequestDto messageRequestDto;
        if (status3.equalsIgnoreCase("empty")) {
            markdown = buildMarkdown(subject, status1, status2);
            messageRequestDto = MessageRequestDto.builder()
                    .markdown(String.format(markdown, totalNumberOfFiles, successCount, failureCount, utc))
                    .build();
        } else {
            markdown = buildMarkdown(subject, status1, status2, status3);
            messageRequestDto = MessageRequestDto.builder()
                    .markdown(String.format(markdown, totalNumberOfFiles, successCount, failureCount, "Need to check", utc))
                    .build();
        }
        log.info("messageRequestDto {}", messageRequestDto);
        return messageRequestDto;
    }

    public static String buildMarkdown(String subject, String status1, String status2) {
        return "<h3>" + subject + TokenConstants.COLON + TokenConstants.B_S_B + "</h3>" +
                "<p>" + status1 + TokenConstants.COLON + TokenConstants.B_S_B + "</p>" +
                "<p>" + status2 + TokenConstants.COLON + TokenConstants.B_S_B + "</p>" +
                "<p>" + "Date" + TokenConstants.COLON + TokenConstants.B_S_B + "</p>";
    }

    public static String buildMarkdown(String subject, String status1, String status2, String status3) {
        return "<h3>" + subject + TokenConstants.COLON + TokenConstants.B_S_B + "</h3>" +
                "<p>" + status1 + TokenConstants.COLON + TokenConstants.B_S_B + "</p>" +
                "<p>" + status2 + TokenConstants.COLON + TokenConstants.B_S_B + "</p>" +
                "<p>" + status3 + TokenConstants.COLON + TokenConstants.B_S_B + "</p>" +
                "<p>" + "Date" + TokenConstants.COLON + TokenConstants.B_S_B + "</p>";
    }

    public static int getTotalNumberOfFiles(List<BatchStatusMetaEntity> metaEntities) {
        return metaEntities.stream()
                .map(BatchStatusMetaEntity::getOriginalFileName)
                .distinct()
                .toList()
                .size();
    }

    public static int getSuccessfulProcessedFilesSize(List<BatchStatusMetaEntity> metaEntities) {
        return metaEntities
                .stream()
                .filter(BatchStatusMetaEntity::isAlreadyRun)
                .map(BatchStatusMetaEntity::getOriginalFileName)
                .filter(Objects::nonNull)
                .distinct()
                .toList()
                .size();
    }

}
